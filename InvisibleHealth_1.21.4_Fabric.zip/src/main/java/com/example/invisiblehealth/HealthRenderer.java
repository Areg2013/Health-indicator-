package com.example.invisiblehealth;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

public final class HealthRenderer {
    private HealthRenderer() {}

    public static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;

        MatrixStack matrices = context.matrixStack();
        Camera camera = context.camera();
        Vec3d cameraPos = camera.getPos();

        VertexConsumerProvider.Immediate consumers =
                client.getBufferBuilders().getEntityVertexConsumers();

        TextRenderer textRenderer = client.textRenderer;

        for (PlayerEntity player : client.world.getPlayers()) {
            if (player == client.player || !player.isInvisible()) continue;

            float health = player.getHealth();
            float max = player.getMaxHealth();
            String hearts = "❤ " + Math.round(health * 10f) / 10f + "/" + Math.round(max * 10f) / 10f;

            Vec3d pos = player.getLerpedPos(context.tickCounter().getTickDelta(true))
                    .add(0, player.getHeight() + 0.35, 0)
                    .subtract(cameraPos);

            matrices.push();
            matrices.translate(pos.x, pos.y, pos.z);
            matrices.multiply(camera.getRotation());
            matrices.scale(-0.025f, -0.025f, 0.025f);

            float x = -textRenderer.getWidth(hearts) / 2f;
            textRenderer.draw(
                    Text.literal(hearts),
                    x, 0,
                    0xFFFFFFFF,
                    true,
                    matrices.peek().getPositionMatrix(),
                    consumers,
                    TextRenderer.TextLayerType.SEE_THROUGH,
                    0,
                    15728880
            );

            matrices.pop();
        }
        consumers.draw();
    }
}
